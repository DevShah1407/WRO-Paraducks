import time, math, csv, os, collections

def clamp(x, lo, hi):
    return max(lo, min(hi, x))

class EMA:
    def __init__(self, alpha):
        self.alpha = alpha
        self.y = None
    def update(self, x):
        if self.y is None:
            self.y = x
        else:
            self.y = self.alpha * x + (1 - self.alpha) * self.y
        return self.y

class PID:
    def __init__(self, kp, ki, kd, i_limit=1.0, d_alpha=0.0):
        self.kp, self.ki, self.kd = kp, ki, kd
        self.i_limit = abs(i_limit)
        self.d_filter = EMA(d_alpha) if kd and d_alpha>0 else None
        self.reset()
    def reset(self):
        self.i = 0.0
        self.prev = None
    def __call__(self, err, dt):
        p = self.kp * err
        self.i = clamp(self.i + self.ki * err * dt, -self.i_limit, self.i_limit)
        d_raw = 0.0 if self.prev is None else (err - self.prev) / max(dt,1e-3)
        d_eff = self.d_filter.update(d_raw) if self.d_filter else d_raw
        self.prev = err
        return p + self.i + self.kd * d_eff

class CSVLogger:
    def __init__(self, path, fieldnames):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.f = open(path, "w", newline="")
        self.w = csv.DictWriter(self.f, fieldnames=fieldnames)
        self.w.writeheader()
    def log(self, **kw):
        self.w.writerow(kw)
    def close(self):
        self.f.close()

class Rate:
    def __init__(self, hz):
        self.dt = 1.0/float(hz)
        self.t = time.time()
    def sleep(self):
        now = time.time()
        delay = self.dt - (now - self.t)
        if delay > 0: time.sleep(delay)
        self.t = time.time()
