import math
from .utils import PID, clamp

class SteeringController:
    def __init__(self, cfg):
        self.pid = PID(**cfg)

    def command_deg(self, lateral_error_m, dt, steer_limit_deg):
        u = self.pid(lateral_error_m, dt)
        return clamp(math.degrees(u), -steer_limit_deg, steer_limit_deg)

class SpeedController:
    def __init__(self, cfg):
        self.pid = PID(**cfg)
    def command(self, speed_err, dt, lo, hi):
        return clamp(self.pid(speed_err, dt), lo, hi)
