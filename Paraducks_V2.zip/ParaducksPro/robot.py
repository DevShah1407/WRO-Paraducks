import time, math, os, yaml, numpy as np
from dataclasses import dataclass
from typing import Optional
from .utils import CSVLogger, Rate, clamp
from .controllers import SteeringController, SpeedController
from .planning import follow_the_gap, speed_from_curvature
from .perception import SignDetection

@dataclass
class Telemetry:
    t: float
    lap: int
    speed: float
    steer_deg: float
    lat_err: float
    curv: float
    sign: str

class Robot:
    def __init__(self, cfg_path="config.yaml", hw=None):
        with open(cfg_path, "r") as f:
            self.cfg = yaml.safe_load(f)
        self.hw = hw or self._mock_hw()
        self.sign_det = SignDetection(self.cfg["perception"]["signs"])
        self.steering = SteeringController(self.cfg["controllers"]["steering_pid"])
        self.speed_ctl = SpeedController(self.cfg["controllers"]["speed_pid"])
        self.lap = 0
        self.last_gate_time = 0
        self.state = "RUN"
        self.logger = None
        if self.cfg["logging"]["enable_csv"]:
            ts = time.strftime("%Y%m%d_%H%M%S")
            path = os.path.join(self.cfg["logging"]["dir"], f"run_{ts}.csv")
            self.logger = CSVLogger(path, fieldnames=list(Telemetry.__annotations__.keys()))

    # ===== entry point =====
    def run(self):
        rate = Rate(30)
        t0 = time.time()
        while self.state != "DONE":
            t = time.time() - t0
            # 1) SENSORS
            angles, ranges = self.hw.lidar_scan()   # np arrays (rad, m)
            frame = self.hw.camera_frame()          # BGR image
            tf_side = self.hw.tfmini_range()        # m

            # 2) PERCEPTION
            lookahead = self.cfg["planning"]["ftg"]["lookahead_m"]
            lat_err, emergency, curv = follow_the_gap(
                angles, ranges,
                self.cfg["planning"]["ftg"]["bubble_radius_m"],
                self.cfg["planning"]["ftg"]["gap_min_width_m"],
                lookahead,
            )
            sign = self.sign_det.detect(frame)
            sign_label = sign[0] if sign else ""
            sign_moving = (sign[3] if sign else False)

            # 3) CONTROL
            dt = 1/30.0
            steer_deg = self.steering.command_deg(lat_err, dt, self.cfg["robot"]["steer_limit_deg"])

            # side distancing (TFmini) nudges steering slightly
            desired = self.cfg["perception"]["tfmini"]["desired_side_distance_m"]
            k_side = self.cfg["perception"]["tfmini"]["k_p"]
            side_err = 0.0 if tf_side is None else (desired - tf_side)
            steer_deg += k_side * side_err * 180.0/math.pi

            # speed schedule
            base = self.cfg["robot"]["cruise_speed_mps"]
            minv = self.cfg["robot"]["min_speed_mps"]
            vmax = speed_from_curvature(base, minv, curv, self.cfg["planning"]["ftg"]["curvature_limit"])
            if emergency: vmax = minv

            # sign rule: keep-left for red, keep-right for green (configurable strategy)
            # Apply small lateral biases for sign passing *only if the sign is not moving*
            if sign_label == "red" and not sign_moving:
                steer_deg += 6.0  # small left bias
            elif sign_label == "green" and not sign_moving:
                steer_deg -= 6.0  # small right bias

            # Extra caution if a sign is moving: slow to min speed
            if sign_moving:
                vmax = self.cfg['robot']['min_speed_mps']

            # 4) ACTUATE
            self.hw.set_speed(vmax)
            self.hw.set_steer(steer_deg)

            # Lap counting via virtual gate (example: every 12s ~ one lap; replace with fiducial detection in real bot)
            if t - self.last_gate_time > 12.0 and self.hw.gate_trigger():
                self.lap += 1
                self.last_gate_time = t
                if self.lap >= self.cfg["robot"]["laps_target"]:
                    self.state = "PARK"

            # 5) PARKING
            if self.state == "PARK":
                ok = self.hw.parallel_park(timeout=self.cfg["robot"]["parking_timeout_s"])
                self.state = "DONE"

            # 6) LOG
            if self.logger:
                rec = Telemetry(t=t, lap=self.lap, speed=vmax, steer_deg=steer_deg, lat_err=lat_err, curv=curv, sign=sign_label)
                self.logger.log(**rec.__dict__)

            rate.sleep()

        if self.logger: self.logger.close()

    # ====== MOCK HARDWARE (replace with actual drivers on Jetson/Coral) ======
    class _mock_hw:
        def __init__(self):
            self.steer = 0; self.speed = 0
            self._ang = np.deg2rad(np.linspace(-135, 135, 361))
            self._gate_count = 0
        def lidar_scan(self):
            rng = 2.0 + 0.5*np.sin(3*self._ang)  # pretend sinusoid walls
            return self._ang, rng
        def camera_frame(self):
            import numpy as np
            return np.zeros((240,320,3), dtype=np.uint8)
        def tfmini_range(self):
            return 0.38
        def set_speed(self, v): self.speed = v
        def set_steer(self, s): self.steer = s
        def gate_trigger(self):
            # pretend a gate every ~13 cycles
            self._gate_count += 1
            if self._gate_count % 390 == 0: return True
            return False
        def parallel_park(self, timeout=30):
            return True

    def _mock_hw(self): return Robot._mock_hw()
