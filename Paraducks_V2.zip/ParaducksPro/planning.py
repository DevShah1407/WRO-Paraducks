import numpy as np, math
from typing import Tuple

def follow_the_gap(angles, ranges, bubble_radius_m, gap_min_width_m, lookahead_m):
    """Return desired lateral offset and curvature proxy.
    angles: np.array [rad], ranges: np.array [m]
    """
    r = np.copy(ranges)
    # Inflate obstacles
    for i in range(1, len(r)-1):
        if np.isfinite(r[i]) and r[i] < r[i-1] and r[i] < r[i+1]:
            # simple local bubble
            inflation = max(0.0, bubble_radius_m - r[i])
            r[i-1] = min(r[i-1], r[i] + inflation)
            r[i+1] = min(r[i+1], r[i] + inflation)

    # Find largest contiguous gap above min width and range
    valid = np.isfinite(r)
    gaps = []
    start = None
    for i, ok in enumerate(valid):
        if ok and start is None: start = i
        if (not ok or i==len(valid)-1) and start is not None:
            end = i if not ok else i
            gaps.append((start, end))
            start = None

    if not gaps:
        return 0.0, True, 0.0  # emergency: go straight, slow

    # Score gaps by angular width * median range
    def score(g):
        s,e = g
        width = abs(angles[e] - angles[s])
        median_r = np.nanmedian(r[s:e+1])
        return width * median_r

    best = max(gaps, key=score)
    s,e = best
    # target angle midway
    a_mid = 0.5*(angles[s] + angles[e])
    # lateral offset at lookahead
    lat = math.tan(a_mid) * lookahead_m
    # curvature proxy from angle spread
    curv = abs(angles[e]-angles[s]) / max(np.nanmedian(r[s:e+1]), 1.0)
    return lat, False, curv

def speed_from_curvature(base_speed, min_speed, curv, limit):
    # scale down by curvature
    factor = max(0.0, 1.0 - min(1.0, curv/limit))
    return max(min_speed, base_speed * (0.5 + 0.5*factor))
