from .robot import Robot

if __name__ == "__main__":
    bot = Robot(cfg_path="config.yaml")
    bot.run()
