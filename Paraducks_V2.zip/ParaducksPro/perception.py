import cv2, numpy as np, time
from collections import deque

class SignDetection:
    """HSV + temporal hysteresis; optional Coral can be integrated.
       Returns tuple (label, bbox, t, moving) where moving is a bool.
    """
    def __init__(self, cfg):
        self.use_coral = cfg["use_coral"]
        self.hsv_cfg = cfg["hsv"]
        self.min_area = cfg["min_area_px"]
        self.hyst_frames = cfg["hysteresis_frames"]
        self.max_age = cfg["max_age_frames"]
        self.state = deque(maxlen=self.hyst_frames)
        self.last = None  # (label, bbox, t, moving)
        self.prev_bbox = None

    def _mask_color(self, hsv, rng):
        hl, sl, vl, hh, sh, vh = rng
        low = np.array([hl, sl, vl], dtype=np.uint8)
        high = np.array([hh, sh, vh], dtype=np.uint8)
        return cv2.inRange(hsv, low, high)

    def detect(self, frame_bgr):
        hsv = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HSV)
        mask_r1 = self._mask_color(hsv, self.hsv_cfg["red1"])
        mask_r2 = self._mask_color(hsv, self.hsv_cfg["red2"])
        mask_red = cv2.bitwise_or(mask_r1, mask_r2)
        mask_green = self._mask_color(hsv, self.hsv_cfg["green"])

        def find(mask, label):
            cnts,_ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            boxes = []
            for c in cnts:
                area = cv2.contourArea(c)
                if area < self.min_area: continue
                x,y,w,h = cv2.boundingRect(c)
                boxes.append((label, (x,y,w,h), area))
            return boxes

        detections = find(mask_red, "red") + find(mask_green, "green")

        chosen = None
        moving = False
        if detections:
            label, bbox, area = max(detections, key=lambda d:d[2])
            self.state.append(label)
            # motion heuristic
            if self.prev_bbox is not None:
                x,y,w,h = bbox
                px,py,pw,ph = self.prev_bbox
                center = (x+w*0.5, y+h*0.5)
                pcenter = (px+pw*0.5, py+ph*0.5)
                dist = np.hypot(center[0]-pcenter[0], center[1]-pcenter[1])
                moving = dist > 6.0  # pixels/frame threshold
            self.prev_bbox = bbox

            # hysteresis
            if len(self.state) == self.hyst_frames and all(s==label for s in self.state):
                chosen = (label, bbox, time.time(), moving)
                self.last = chosen
        else:
            self.state.append(None)

        return self.last
