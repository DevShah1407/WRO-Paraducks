# ParaducksPro – Upgraded WRO Obstacle Challenge Stack

This is a modular, competition‑tuned rewrite of your previous single‑file script. Key improvements:

- **Modular architecture** (`perception`, `planning`, `controllers`, `robot`) with a clean `config.yaml` so you can tune on‑site in minutes.
- **Follow‑the‑Gap (FTG) planner** on LiDAR for robust obstacle avoidance and lane‑center targeting.
- **Curvature‑aware speed governor** that auto‑slows in tight turns; safer and faster lap times.
- **Hardened PID** (anti‑windup + filtered derivative) for smooth steering and speed control.
- **Side‑distance hold** using TFmini to keep safe clearance from barriers/signs.
- **Traffic‑sign handling** (HSV with temporal hysteresis). If you add Coral, insert your classifier in `perception.SignDetection`.
- **Telemetry logger** (`/logs/run_*.csv`) with speed, steering, curvature, sign state, and lap count.
- **FSM**: `RUN → PARK → DONE`. Parallel parking entry point is abstracted to `hw.parallel_park()`.

## Quick start
1. Copy this folder to your Jetson Nano/Raspberry Pi.
2. Edit `config.yaml` for your car (wheelbase, max steering, speeds, gains).
3. Implement your real hardware drivers by replacing the `_mock_hw` class in `robot.py` with motor/servo/LiDAR/camera/TFmini adapters.
4. Run:
```bash
python3 -m ParaducksPro.main
```

## What to tune first on the real robot
- `controllers.steering_pid.kp/ki/kd` – start with Ki=0; add slowly.
- `planning.ftg.lookahead_m` – larger = calmer but slower; smaller = agile but twitchy.
- `planning.ftg.bubble_radius_m` – increase if you’re clipping signs.
- `perception.signs.hsv.*` – calibrate **on-field** under the event lighting.
- `robot.max_speed_mps`, `robot.cruise_speed_mps` – raise gradually after you stop derailing.

## Integrating Coral (optional)
Inside `perception.py → SignDetection`, route frames to your EdgeTPU model and set `self.last = ("red" | "green", bbox, time.time())` when confident. Keep HSV as a fallback.

## Parking
`robot.py → hw.parallel_park()` is an abstraction. You can implement a simple 3‑move maneuver using TFmini/odometry or vision markers.
